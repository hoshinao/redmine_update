create definer = root@localhost view zukosha_user_list as
select `a`.`id`                 AS `id`,
       `a`.`login`              AS `login`,
       `a`.`hashed_password`    AS `hashed_password`,
       `a`.`firstname`          AS `firstname`,
       `a`.`lastname`           AS `lastname`,
       `a`.`admin`              AS `admin`,
       `a`.`status`             AS `status`,
       `a`.`last_login_on`      AS `last_login_on`,
       `a`.`language`           AS `language`,
       `a`.`auth_source_id`     AS `auth_source_id`,
       `a`.`created_on`         AS `created_on`,
       `a`.`updated_on`         AS `updated_on`,
       `a`.`type`               AS `type`,
       `a`.`identity_url`       AS `identity_url`,
       `a`.`mail_notification`  AS `mail_notification`,
       `a`.`salt`               AS `salt`,
       `a`.`must_change_passwd` AS `must_change_passwd`,
       `a`.`passwd_changed_on`  AS `passwd_changed_on`
from ((select `redmine`.`users`.`id`                 AS `id`,
              `redmine`.`users`.`login`              AS `login`,
              `redmine`.`users`.`hashed_password`    AS `hashed_password`,
              `redmine`.`users`.`firstname`          AS `firstname`,
              `redmine`.`users`.`lastname`           AS `lastname`,
              `redmine`.`users`.`admin`              AS `admin`,
              `redmine`.`users`.`status`             AS `status`,
              `redmine`.`users`.`last_login_on`      AS `last_login_on`,
              `redmine`.`users`.`language`           AS `language`,
              `redmine`.`users`.`auth_source_id`     AS `auth_source_id`,
              `redmine`.`users`.`created_on`         AS `created_on`,
              `redmine`.`users`.`updated_on`         AS `updated_on`,
              `redmine`.`users`.`type`               AS `type`,
              `redmine`.`users`.`identity_url`       AS `identity_url`,
              `redmine`.`users`.`mail_notification`  AS `mail_notification`,
              `redmine`.`users`.`salt`               AS `salt`,
              `redmine`.`users`.`must_change_passwd` AS `must_change_passwd`,
              `redmine`.`users`.`passwd_changed_on`  AS `passwd_changed_on`
       from `redmine`.`users`
       where (`redmine`.`users`.`type` = 'User')) `a`
         join (select `redmine`.`groups_users`.`group_id` AS `group_id`, `redmine`.`groups_users`.`user_id` AS `user_id`
               from `redmine`.`groups_users`
               where (`redmine`.`groups_users`.`group_id` = 389)) `b` on ((`a`.`id` = `b`.`user_id`)));

